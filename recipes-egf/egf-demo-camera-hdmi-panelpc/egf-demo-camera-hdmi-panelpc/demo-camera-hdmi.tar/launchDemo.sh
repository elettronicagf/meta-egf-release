export DISPLAY=:0.0
cd /home/root/demo-camera-hdmi
python DemoCameraHDMI.py
