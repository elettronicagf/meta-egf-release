gst-launch-1.0 imxv4l2src device=/dev/video0 ! 'video/x-raw,framerate=(fraction)30/1,format=(string)I420,interlace-mode=progressive, width=(int)1280, height=(int)720' ! imxvideoconvert_ipu rotation=2 ! imxv4l2sink device="/dev/video18"

