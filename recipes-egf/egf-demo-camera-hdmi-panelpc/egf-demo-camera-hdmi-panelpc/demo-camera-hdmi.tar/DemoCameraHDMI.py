import sys
import os
import sys
import subprocess

LOCKFILE = "/var/volatile/DemoHDMI.lock"

#Evita di lanciare piu' istanze del programma utilizzando
#un file di lock residente in RAM
if (os.path.isfile(LOCKFILE)):
	print "There is an instance of this program already running!"
	sys.exit(1)

fp = open(LOCKFILE, 'w')
fp.close()

proc = subprocess.Popen("./gstcommand.sh", shell = True)
proc.wait()

os.remove(LOCKFILE)
