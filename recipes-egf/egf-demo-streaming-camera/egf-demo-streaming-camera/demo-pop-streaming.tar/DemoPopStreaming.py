import subprocess
import time
import os
import traceback
import threading
import socket
WLAN_SERVER_ADDRESS = "192.168.59.254"
LAN_SERVER_ADDRESS = "192.168.60.254"

DATA_SEND_PORT = 5005

class SendDataThread(threading.Thread):
	def getBatteryVoltage(self):
		try:
			stdout= os.popen("cat /sys/bus/i2c/drivers/mcp3021/0-004d/in0_input").read()
			value = int(stdout.rstrip("\n"))
			realValue = int((float(value) * 4) / 3) 
			return realValue
		except:
			traceback.print_exc()
			print "Invalid battery value read"
			return -1
	
	def getChargingStatus(self):
		try:
			stdout = os.popen("getGpio_in 127").read()
			pg = int(stdout.rstrip("\n"))
			return pg == 0
		except:
			traceback.print_exc()
			return -1
		
	def run(self):
		while(True):
			chargingStatus = self.getChargingStatus()
			batteryVoltage = self.getBatteryVoltage()
			try:
				self._sock.sendto("[" + str(chargingStatus) + "," + str(batteryVoltage) + "]", (self._ip, DATA_SEND_PORT))
			except:
				pass
			time.sleep(2)
		
	def __init__(self, ip):
		threading.Thread.__init__(self)
		self._ip = ip
		self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

def ping(IPAddress):
	proc = subprocess.Popen("ping -c 1 -w 1 " + IPAddress, 
							shell = True, stdout = subprocess.PIPE)
	ret,err = proc.communicate()
	print ret
	index = ret.find("from") 
	if (index == -1):
		return False
	else:
		return True
		
def checkConnection():
	print "Check Connection"
	#Try Ethernet
	count = 1
	while(count < 3):
		print "LAN"
		ret = ping(LAN_SERVER_ADDRESS)
		if (ret == True):
			return LAN_SERVER_ADDRESS
		time.sleep(2)
		count = count + 1
	#Try WLAN
	count = 1
	while(count < 3):
		print "WLAN"
		ret = ping(WLAN_SERVER_ADDRESS)
		if (ret == True):
			return WLAN_SERVER_ADDRESS
		time.sleep(2)
		count = count + 1	
	return None

def waitConnection():
	ret = checkConnection()
	while(ret == None):
		#Restart interfaces
		proc = subprocess.Popen("ifdown eth0", shell=True)
		proc.wait()
		proc = subprocess.Popen("ifup eth0", shell=True)
		proc.wait()	
		proc = subprocess.Popen("ifdown wlan0", shell=True)
		proc.wait()
		proc = subprocess.Popen("ifup wlan0", shell=True)
		proc.wait()			
		ret = checkConnection()
	return ret

serverIP = waitConnection()
print "Connesso a " + str(serverIP)
if (serverIP == WLAN_SERVER_ADDRESS):
	cmd = "/home/root/demo-pop-streaming/gst-pipe-wlan.sh"
else:
	cmd = "/home/root/demo-pop-streaming/gst-pipe-lan.sh"

dataThread = SendDataThread(serverIP)
dataThread.start()
procGst = subprocess.Popen(cmd, shell = True, preexec_fn=os.setsid)
procGst.wait()
