gst-launch-1.0 imxv4l2src device=/dev/video0 ! 'video/x-raw,framerate=(fraction)30/1,format=(string)I420,interlace-mode=progressive, 
width=(int)1280, height=(int)720' ! vpuenc_h264 bitrate=5000 ! rtph264pay ! udpsink host=192.168.59.254 port=9001 sync=false async=false -v
