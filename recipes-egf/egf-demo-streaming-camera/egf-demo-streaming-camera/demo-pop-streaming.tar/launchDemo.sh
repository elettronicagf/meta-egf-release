until python /home/root/demo-pop-streaming/DemoPopStreaming.py; do
    echo "process crashed with exit code $?.  Respawning.." >&2
    sleep 1
done
