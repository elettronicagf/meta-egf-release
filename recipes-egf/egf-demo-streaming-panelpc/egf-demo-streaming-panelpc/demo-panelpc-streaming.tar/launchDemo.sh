export DISPLAY=:0.0
cd /home/root/demo-panelpc-streaming
python DemoStreaming.py
