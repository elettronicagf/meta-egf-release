from PyQt4 import QtCore, QtGui, Qt
from PyQt4.QtCore import QTimer
import time
import traceback
import subprocess
import socket 
import traceback

SSH_CMD_OPTIONS = "-o ConnectTimeout=1 -o BatchMode=yes -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -x"

BATT_LEVEL_SERVICE_PORT = 5005

class CheckBatteryLevel(QtCore.QThread):
    newBatteryLevel = QtCore.pyqtSignal(bool,bool,int)
    lastValues = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    _cameraIP = None
    
    def getBatteryValue(self):
	try:
		self.proc = subprocess.Popen("ssh " + SSH_CMD_OPTIONS + " root@" + self._cameraIP + 
									 " cat /sys/bus/i2c/drivers/mcp3021/0-004d/in0_input", 
									 shell = True, stdout = subprocess.PIPE)
		stdout, stderr = self.proc.communicate()
		value = int(stdout.rstrip("\n"))
		realValue = int((float(value) * 4) / 3) 
		return realValue
	except:
		traceback.print_exc()
		print "Invalid battery value read"
		return None

    def getChargingStatus(self):
	try:
		self.proc = subprocess.Popen("ssh " + SSH_CMD_OPTIONS + " root@" + self._cameraIP + 
									 " getGpio_in 127", shell = True, 
									 stdout = subprocess.PIPE, stderr = None)
		stdout, stderr = self.proc.communicate()
		pg = int(stdout.rstrip("\n"))
		return pg == 0
	except:
		traceback.print_exc()
		return None

    def getAverageBatteryLevel(self):
		sum = 0
		numValues = 0
		for value in self.lastValues:
			if (value != 0):
				sum = sum + value
				numValues = numValues + 1
		average =  sum / numValues
		return average
	
    def getBatteryPercentage(self,value):
		if (value > 4010):
			percentage = 100
		elif(value > 3850 and value <= 4010):
			delta = value - 3850
			percentage = 100 - 14 + (14 * delta) / 160
		elif(value > 3750 and value <= 3850):
			delta = value - 3750
			percentage = 100 - 14 -14 + (14 * delta) / 100
		elif(value > 3680 and value <= 3750):
			delta = value - 3680
			percentage = 100 - 14 -14 -14 + (14 * delta) / 70		 
		elif(value > 3630 and value <= 3680):
			delta = value - 3630
			percentage = 100 - 14 -14 - 14 - 14 + (14 * delta) / 50	
		elif(value > 3590 and value <= 3630):
			delta = value - 3590
			percentage = 100 - 14 -14 - 14 - 14 - 14 + (14 * delta) / 40	
		elif(value > 3560 and value <= 3590):
			delta = value - 3560
			percentage = 100 - 14 -14 - 14 - 14 - 14 -14 + (14 * delta) / 30	
		elif(value > 3530 and value <= 3560):
			delta = value - 3560
			percentage = 100 - 14 -14 - 14 - 14 - 14 -14 -7 + (7 * delta) / 30	
		elif(value > 3450 and value <=3530 ):
			percentage = 7
		else:
			percentage = 0
		return percentage

    def run(self):	
		index = 0
		errCount = 0
		while(True):
			if (index >= 16):
				index = 0
			#isCharging = self.getChargingStatus()
			#print isCharging

			#if (isCharging == None):
			#	self.newBatteryLevel.emit(False, False, 0)
			#elif (isCharging == True):
			#	self.newBatteryLevel.emit(True, True, 0)
			#else:
			#	battValue = self.getBatteryValue()
			#	if (battValue != None):
			#		self.lastValues[index] = battValue
			#		index = index + 1
			#		self.newBatteryLevel.emit(True, False, self.getBatteryPercentage(self.getAverageBatteryLevel()))
			#time.sleep(5)
			try:
				data, addr = self.sock.recvfrom(1024)
				print "Received from socket: " + data
				errCount = 0
				if (data.startswith("[") and data.endswith("]")):
					data = data[1:-1]
					data = data.split(",")
					print data
					if (data[0] == "-1"):
						isCharging = None
					elif (data[0] == "True"):
						isCharging = True
					else:
						isCharging = False
					if (isCharging == None):
						print "Received is Charging None from socket"
						self.newBatteryLevel.emit(False, False, 0)
					elif (isCharging == True):
						self.newBatteryLevel.emit(True, True, 0)
					else:
						if (data[1] == "-1"):
							battValue = None
						else:
							battValue = int(data[1])
						if (battValue != None):
							self.lastValues[index] = battValue
							index = index + 1
							self.newBatteryLevel.emit(True, False, self.getBatteryPercentage(self.getAverageBatteryLevel()))
				
			except socket.error, e:
				err = e.args[0]
				if (err == 11):
					errCount = errCount + 1
					if (errCount > 2):
						print "Disconnected from too many errors!"
						self.newBatteryLevel.emit(False, False, 0)
						time.sleep(2)
				traceback.print_exc()
				pass
			except:
				traceback.print_exc()
				pass				
			time.sleep(2)
			
    
    def __init__(self, cameraIP):
		super(CheckBatteryLevel, self).__init__()
		self._cameraIP = cameraIP
		self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) 
		self.sock.setblocking(False)
		self.sock.bind(("", BATT_LEVEL_SERVICE_PORT))

