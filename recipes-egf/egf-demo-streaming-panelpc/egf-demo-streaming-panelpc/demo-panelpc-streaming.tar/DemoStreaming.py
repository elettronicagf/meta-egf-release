import sys
from PyQt4 import QtCore, QtGui
from PyQt4.QtCore import QTimer
import MainWindow
import CheckBatteryLevel
import signal
import os
import sys
import subprocess

LOCKFILE = "/var/volatile/DemoStreaming.lock"
CAMERA_IDENTIFICATION_FILE = "/home/root/egf.camera"

CAMERA_IP_ADDRESSES = [	"192.168.59.100", 
						"192.168.59.101",
						"192.168.59.102", 
						"192.168.59.103", 
						"192.168.59.104",
						"192.168.60.100", 
						"192.168.60.101",
						"192.168.60.102", 
						"192.168.60.103", 
						"192.168.60.104"]

SSH_CMD_OPTIONS = "-o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -x"

class WorkerThread(QtCore.QThread):
    finished = QtCore.pyqtSignal()
    ret = None
    def run(self):
        self.ret = self._func()
        self.finished.emit()
    def __init__(self, func):
        super(WorkerThread, self).__init__()
        self._func = func
           
def exitProgram():
	try:
		os.remove(LOCKFILE)
	except:
		pass
	sys.exit(1)

def ping(IPAddress):
	proc = subprocess.Popen("ping -c 1 -w 1 " + IPAddress, 
							shell = True, stdout = subprocess.PIPE)
	ret,err = proc.communicate()
	index = ret.find("from") 
	if (index == -1):
		return False
	else:
		return True

def isEgfCamera(IPAddress):
	proc = subprocess.Popen("ssh " + SSH_CMD_OPTIONS + " root@" + 
							IPAddress + " ls " + CAMERA_IDENTIFICATION_FILE, 
							shell = True, stdout = subprocess.PIPE)
	ret,err = proc.communicate()
	ret = ret.rstrip("\n")
	return ret == CAMERA_IDENTIFICATION_FILE

def detectCamera():
	while True:
		for ip in CAMERA_IP_ADDRESSES:
			ret = ping(ip)
			if (ret == True):
				if (isEgfCamera(ip)):
					return ip

app = QtGui.QApplication(sys.argv)

progressDialog = QtGui.QProgressDialog("Waiting for camera connection...", "", 0, 0, parent = None)
progressDialog.setWindowTitle("Smart Camera i.MX6 Demo Streaming")
progressDialog.setCancelButtonText(QtCore.QString())
progressDialog.open()
evLoop = QtCore.QEventLoop()
timeoutTimer = QTimer()
timeoutTimer.setSingleShot(True)
worker = WorkerThread(detectCamera)
timeoutTimer.timeout.connect(evLoop.quit)
worker.finished.connect(evLoop.quit)
timeoutTimer.start(60000)
worker.start()
evLoop.exec_()
progressDialog.cancel()

if(timeoutTimer.isActive()):
	timeoutTimer.stop()
	cameraIP = worker.ret
else:
	cameraIP = None

if (cameraIP == None):
	print "Camera not detected!"
	exitProgram()
print "Camera is " + cameraIP

#Evita di lanciare piu' istanze del programma utilizzando
#un file di lock residente in RAM
if (os.path.isfile(LOCKFILE)):
	print "There is an instance of this program already running!"
	sys.exit(1)

fp = open(LOCKFILE, 'w')
fp.close()

myWindow = MainWindow.MainWindow()
myWindow.finished.connect(exitProgram)
signal.signal(signal.SIGINT, myWindow.exitProgram)

batteryMonitorThread = CheckBatteryLevel.CheckBatteryLevel(cameraIP)
batteryMonitorThread.newBatteryLevel.connect(myWindow.updateBatteryInfo)
batteryMonitorThread.start()

myWindow.showFullScreen()
app.exec_()

