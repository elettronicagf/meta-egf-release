from PyQt4 import QtCore, QtGui, Qt
import Ui_MainWindow
import subprocess
import time
import sys
from PyQt4.QtCore import QTimer
import os
import traceback

class MainWindow(QtGui.QMainWindow, Ui_MainWindow.Ui_MainWindow):
    isCharging = False
    isConnected = False
    batteryValue =  0
    videoPlaying = False
    procGst = None
    finished = QtCore.pyqtSignal()

    def exitProgram(self, dbg1 = None, dbg2 = None):
		processPid = self.procGst.pid
		try:
			os.killpg(processPid, 2)
		except:
			traceback.print_exc()
			pass
		self.finished.emit()

    def updateBatteryInfo(self, connectionStatus, chargingStatus, value):
		print "Update Battery Info " + str(connectionStatus) + " " + str(chargingStatus) + " " + str(value)
		if (connectionStatus == False):
			self.isConnected = False
			self.isCharging = None
			self.batteryValue = None
		else:
			if (chargingStatus == True):
				self.isConnected = True
				self.isCharging = True
				self.batteryValue = None
			else:
				self.isConnected = True
				self.isCharging = False
				self.batteryValue = value		

    def updateBatteryIcon(self):
		print "update GUI " + str(self.isConnected) + " " + str(self.isCharging) + " " + str(self.batteryValue)
		if (self.isConnected == False):
			#Telecamera non connessa
			self.batteryValueLabel.setText("Disconnected")
			self.batteryLevelIndicator.setValue(0)
		else:
			#Telecamera connessa
			if (self.isCharging == True):
				#Telecamera in carica: visualizza una animazione dell'indicatore
				#di batteria
				self.batteryValueLabel.setText("Charging...")
				currentProgressValue = self.batteryLevelIndicator.value()	
				progressValue = currentProgressValue + 10
				if (progressValue > 100):
					progressValue = 0
				self.batteryLevelIndicator.setValue(progressValue)
			else:
				#Telecamera non in carica: visualizza la percentuale di carica
				self.batteryValueLabel.setText(str(self.batteryValue) + " %")
				self.batteryLevelIndicator.setValue(self.batteryValue)
		#Aggiorna l'indicatore di batteria
		self.batteryLevelIndicator.repaint()

    def launchStreaming(self, parent = None):
		screenShape = QtGui.QDesktopWidget().screenGeometry()
		width = screenShape.width()
		height = screenShape.height()
		print width
		print height
		cmd = "./gstcommand-" + str(width) + "x" + str(height) + ".sh"
		self.procGst = subprocess.Popen(cmd, shell=True, preexec_fn=os.setsid)
		self.videoPlaying = True

    def __init__(self, parent = None):
		QtGui.QMainWindow.__init__(self, parent)
		self.setupUi(self)
		self.pushButton.clicked.connect(self.exitProgram)
		self.timer = QTimer()
		self.timer.timeout.connect(self.updateBatteryIcon)
		self.timer.start(500)
		self.launchStreaming()



